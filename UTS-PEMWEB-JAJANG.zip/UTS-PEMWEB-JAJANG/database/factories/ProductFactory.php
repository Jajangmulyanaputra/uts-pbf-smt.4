<?php

namespace Database\Factories;

use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Product>
 */

class ProductFactory extends Factory
{
    protected $model = Product::class;

    public function definition()
    {
        $categories = ['Laptop', 'Keyboard', 'VGA'];
        $category = $this->faker->randomElement($categories);

        // Daftar merek laptop
        $laptopBrands = [
            'Apple MacBook',
            'Dell XPS',
            'HP Spectre',
            'Lenovo ThinkPad',
            'Asus ZenBook',
            'Acer Swift',
            'Microsoft Surface',
            'Razer Blade',
            'MSI',
            'Samsung Notebook'
        ];

        // Daftar merek keyboard
        $keyboardBrands = [
            'Logitech',
            'Razer',
            'Corsair',
            'SteelSeries',
            'Microsoft',
            'Asus',
            'HP',
            'Dell',
            'Cooler Master',
            'HyperX'
        ];

        // Daftar merek VGA
        $vgaBrands = [
            'NVIDIA GeForce',
            'AMD Radeon',
            'Asus ROG Strix',
            'MSI Gaming',
            'Gigabyte Aorus',
            'EVGA',
            'Zotac',
            'Sapphire',
            'PowerColor',
            'XFX'
        ];

        $name = $category == 'Laptop'
            ? $this->faker->randomElement($laptopBrands)
            : ($category == 'Keyboard'
                ? $this->faker->randomElement($keyboardBrands)
                : $this->faker->randomElement($vgaBrands));

        $description = $category == 'Laptop'
            ? $this->faker->randomElement([
                'Laptop dengan performa tinggi dan desain elegan.',
                'Dilengkapi dengan prosesor terbaru dan baterai tahan lama.',
                'Laptop ringan dan portabel untuk produktivitas maksimal.'
            ])
            : ($category == 'Keyboard'
                ? $this->faker->randomElement([
                    'Keyboard mekanik dengan respons cepat.',
                    'Desain ergonomis dan nyaman digunakan.',
                    'Keyboard gaming dengan lampu RGB yang keren.'
                ])
                : $this->faker->randomElement([
                    'VGA dengan performa grafis tinggi.',
                    'Mendukung gaming dan rendering yang lancar.',
                    'Dilengkapi dengan teknologi pendinginan terbaru.'
                ]));

        return [
            'name' => $name,
            'description' => $description,
            'price' => $this->faker->numberBetween(500000, 50000000),
            'image' => $this->faker->imageUrl(640, 480, 'product', true),
            'category_id' => $category == 'Laptop' ? 1 : ($category == 'Keyboard' ? 2 : 3),
            'expired_at' => now()->addDays(365),
            'modified_by' => $this->faker->randomElement(['user@gmail.com', 'jajang@gmail.com'])
        ];
    }
}
